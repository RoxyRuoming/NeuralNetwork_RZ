This is a script in Python that does a similar thing using various libraries
to what we're doing in Java without any libraries.

If you want to run it, you have to install Python and any missing libraries the
script requires.


