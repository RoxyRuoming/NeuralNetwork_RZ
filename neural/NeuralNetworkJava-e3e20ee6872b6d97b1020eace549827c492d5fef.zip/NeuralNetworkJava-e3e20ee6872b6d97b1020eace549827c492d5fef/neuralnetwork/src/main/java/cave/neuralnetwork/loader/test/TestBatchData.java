package cave.neuralnetwork.loader.test;

import cave.neuralnetwork.loader.AbstractBatchData;

public class TestBatchData extends AbstractBatchData {

}
