package cave.neuralnetwork;

public enum LossFunction {
	CROSSENTROPY, MEANSQUARES
}
