package cave.neuralnetwork;

public enum Transform {
	DENSE, RELU, SOFTMAX
}
