package cave.neuralnetwork.loader.test;

import cave.neuralnetwork.loader.AbstractMetaData;

public class TestMetaData extends AbstractMetaData {

}
